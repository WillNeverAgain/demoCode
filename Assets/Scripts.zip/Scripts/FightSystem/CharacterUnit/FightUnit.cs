//Author : _SourceCode
//CreateTime : 2025-08-12-01:26:21
//Version : 0.1
//UnityVersion : 2022.3.62f1c1

using MyFrame.FightSystem.Buff;
using MyFrame.FightSystem.Calculator;
using MyFrame.FightSystem.Skill;
using System.Collections.Generic;

namespace MyFrame.FightSystem.Unit
{
    public class FightUnit : FightObject,ISkillTarget, ISkillExecuter,IBuffOwner
    {
        public bool WhenSelected(SkillContext sctx)
        {
            return true;
        }
        public SkillReport ExecuteSkill(ISkill skill, SkillContext sctx, TargetPos aim)
        {
            return skill.Execute(sctx, aim);
        }

        public void OnBuffAttached(IBuffInstance buff)
        {
            return;
        }

        public void OnBuffDetached(IBuffInstance buff)
        {
            return ;
        }
    }


    public interface IFightObject
    {
        public FightObjectType TargetType { get; }
        public float? GetAttributeValue(StatType type);
        public void Damage(float amount);
        public List<IValueModifier<T>> GetModifiers<T>() where T : IValueContext;
        public void AddAttributeModifier(StatType type, IValueModifier<StatContext> modifier);
        public void RemoveAttributeModifier(StatType type, IValueModifier<StatContext> modifier);
        public void SetAttributeValue(StatType type,float value);
    }

    public class FightObject : IFightObject
    {
        public FightObjectType TargetType { get; }
        public IGameMap _map { get; }
        private IAttribute<StatContext> attribute;
        public float? GetAttributeValue(StatType type)
        {
            if (attribute.GetValue(GetNoneAttibuteStatContext()).TryGetValue(type, out var value))
                return value.Value;
            return null;
        }
        /// <summary>
        /// ��δʵ��
        /// </summary>
        /// <param name="amount"></param>
        public void Damage(float amount)
        {
            return;
        }

        private StatContext GetNoneAttibuteStatContext()
        {
            return new StatContext();
        }
        private StatContext GetStatContext()
        {
            StatContext sctx = GetNoneAttibuteStatContext();
            sctx.UnitAttribute = attribute.GetValue(GetNoneAttibuteStatContext());
            return sctx;
        }


        public List<IValueModifier<T>> GetModifiers<T>() where T : IValueContext
        {
            return new List<IValueModifier<T>>();
        }

        public void AddAttributeModifier(StatType type, IValueModifier<StatContext> modifier)
        {
            attribute.AddModifier(type, modifier);
        }

        public void RemoveAttributeModifier(StatType type, IValueModifier<StatContext> modifier)
        {
            attribute.RemoveModifier(type, modifier);
        }
        public void SetAttributeValue(StatType type,float value)
        {
            attribute.SetValue(type, value);
        }
    }

}