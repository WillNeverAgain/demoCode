//Author : _SourceCode
//CreateTime : 2025-09-18-08:03:13
//Version : 0.1
//UnityVersion : 2022.3.62f1c1

using MyFrame.FightSystem.Calculator;

namespace MyFrame.FightSystem.Unit
{
    public class StatCalculatorEasyGet : IStatCalculator
    {
        private readonly IValueCalculator _valueCalculator;
        public T Evaluate<T>(StatSpec<T> spec, StatEvaluateCommand command)
        {
            throw new System.NotImplementedException();
        }
    }
}
