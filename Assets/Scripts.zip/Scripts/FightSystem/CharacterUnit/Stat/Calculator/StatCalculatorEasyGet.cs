//Author : _SourceCode
//CreateTime : 2025-09-18-08:03:13
//Version : 0.1
//UnityVersion : 2022.3.62f1c1

using MyFrame.FightSystem.Calculator;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Runtime.Serialization;

namespace MyFrame.FightSystem.Unit
{
    /// <summary>
    /// δ���뻷�����㷨���޷������໥���������ĿǰΪ���׵�ֱ������.���䷺����valuebreakdown��Ϊfloat��valuecalculatorֻ�ܼ���float�Ͳ�����ͻ����Ҫ��demo���ǽ����ʽ
    /// </summary>
    public class StatCalculatorEasyGet : IStatCalculator
    {
        private readonly IValueCalculator _valueCalculator;
        public StatResult<T> Evaluate<T>(StatSpec<T> spec, StatEvaluateCommand command)
        {
            var base_value = command.repo.ReadBase(spec);
            //���û����������ֱ�ӷ���
            if (!command.modIndex.HasAny(command.ctx, spec, out long current_version_mod)) { return new StatResult<T>(base_value, base_value, Array.Empty<string>()); }
            if(spec.valueType != typeof(float)) { throw new StatCalculatorException("float types cannot contain correctors,There must be something wrong with your code!"); }

            //���Զ�ȡ����ֵ
            if(command.cache.TryGet(command.ctx,spec, command.repo.Version, out var cache_value))
            {
                return cache_value;
            }
            //����Ϊ�����ؼ���
            var new_value = _valueCalculator.Compute(command.ctx, command.modIndex.Query(command.ctx, spec, out long current_version_query), new ValueBreakdown(command.repo.ReadBase<float>((StatSpec<float>)(object)spec)));
            return new StatResult<T>(base_value,(T)(object)new_value.Result,new_value.Notes);
        }

        public bool TryEvaluate<T>(StatSpec<T> spec, StatEvaluateCommand command, out StatResult<T> value)
        {
            value = null;
            var base_value = command.repo.ReadBase(spec);
            //���û����������ֱ�ӷ���
            if (!command.modIndex.HasAny(command.ctx, spec, out long current_version_mod)) {
                value = new StatResult<T>(base_value, base_value, Array.Empty<string>());
                return true;
            }
            if (spec.valueType != typeof(float)) { return false; }

            //���Զ�ȡ����ֵ
            if (command.cache.TryGet(command.ctx, spec, command.repo.Version, out var cache_value))
            {
                value = cache_value;
                return true;
            }
            //����Ϊ�����ؼ���
            var new_value = _valueCalculator.Compute(command.ctx, command.modIndex.Query(command.ctx, spec, out long current_version_query), new ValueBreakdown(command.repo.ReadBase<float>((StatSpec<float>)(object)spec)));
            value = new StatResult<T>(base_value, (T)(object)new_value.Result, new_value.Notes);
            return true;
        }
    }

    [Serializable]
    internal class StatCalculatorException : Exception
    {
        public StatCalculatorException()
        {
        }

        public StatCalculatorException(string message) : base(message)
        {
        }

        public StatCalculatorException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected StatCalculatorException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
