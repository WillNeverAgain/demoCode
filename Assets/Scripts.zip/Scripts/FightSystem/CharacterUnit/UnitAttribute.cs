//Author : _SourceCode
//CreateTime : 2025-08-25-17:44:17
//Version : 0.1
//UnityVersion : 2022.3.62f1c1

using MyFrame.FightSystem.Calculator;
using System.Collections.ObjectModel;

namespace MyFrame.FightSystem.Unit
{
    public class UnitAttribute : IAttribute<StatContext>
    {
        private readonly IAttributeCalculator<StatContext> _attributeCalculator;
        private readonly IAttributeData<StatContext> _data;

        private ReadOnlyDictionary<StatType,AttributeDataUnit<StatContext>> _last;

        public UnitAttribute(IAttributeCalculator<StatContext> attributeCalculator, IAttributeData<StatContext> data, ReadOnlyDictionary<StatType, AttributeDataUnit<StatContext>> last)
        {
            _attributeCalculator = attributeCalculator;
            _data = data;
            _last = last;
        }

        public void AddModifier(StatType type,IValueModifier<StatContext> valueModifier)
        {
            _data.AddModifier(type, valueModifier);
        }

        /// <summary>
        /// ��ȡֵ��ͬʱ�������Ա��������ctx����Ҫ�������Ա�
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns></returns>
        public ReadOnlyDictionary<StatType, AttributeDataUnit<StatContext>> GetValue(StatContext ctx)
        {
            ctx.UnitAttribute = _attributeCalculator.GetValue(ctx , _data);
            if ( !CalculateDirty(ctx)) { return _last; }

            //�ؼ���
            _last = _attributeCalculator.GetValue(ctx , _data);

            return _last;
        }

        public void RemoveModifier(StatType type,IValueModifier<StatContext> valueModifier)
        {
            _data.RemoveModifier(type, valueModifier);
        }

        public void SetValue(StatType type, float value)
        {
            _data.SetValue(type, value);
        }

        /// <summary>
        /// �������ǣ������Ƿ�����
        /// </summary>
        /// <param name="ctx"></param>
        /// <returns></returns>
        private bool CalculateDirty(StatContext ctx)
        {
            return true;
        }


    }
}
