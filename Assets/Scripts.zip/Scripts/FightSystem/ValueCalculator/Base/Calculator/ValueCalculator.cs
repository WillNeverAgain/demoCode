//Author : _SourceCode
//CreateTime : 2025-08-12-01:21:49
//Version : 0.1
//UnityVersion : 2022.3.62f1c1

using System;
using System.Collections.Generic;

namespace MyFrame.FightSystem.Calculator
{
    public class ValueCalculator : IValueCalculator
    {
        /// <summary>
        /// ���������˺�
        /// </summary>
        /// <param name="ctx">���������ģ�����Ӱ�����ݵ�����</param>
        /// <param name="all_mods">��������������������Ӧ��Ӧ�õĹ���</param>
        /// <returns>������������������ʼֵ������ֵ�Լ���Դ��¼</returns>
        public ValueBreakdown Compute<T, U>(in T ctx, IEnumerable<U> all_mods , ValueBreakdown bd)
            where T : IValueContext
            where U : IValueModifier<T>
        {
            float value = bd.Result;

            value = applyStage(ctx, all_mods, value, ModifierStage.PreAdd,ref bd);
            value = applyStage(ctx, all_mods, value, ModifierStage.Multiplier,ref bd);
            value = applyStage(ctx, all_mods, value, ModifierStage.PostAdd,ref bd);
            value = applyStage(ctx, all_mods, value, ModifierStage.Finalize,ref bd);

            value = MathF.Ceiling(value);

            bd.Result = value;

            return bd;
        }

        private float applyStage<T, U>(in T ctx , IEnumerable<U> all_mods ,float current_value , ModifierStage current_stage,ref ValueBreakdown bd) 
            where T : IValueContext
            where U : IValueModifier<T>
        {
            float addSum = 0f;
            float mulProd = 1f;
            float cur = current_value;

            foreach (var m in all_mods)
            {
                if (m.Stage != current_stage || !m.ApplyTo(ctx)) continue;

                switch (m.Stacking)
                {
                    case StageStacking.Additive:
                        var add = m.GetValue(ctx);
                        addSum += add;
                        bd.Notes.Add($"+{add} ���� {m.Source}");
                        break;

                    case StageStacking.Multiplicative:
                        var mul = m.GetValue(ctx);
                        mulProd *= mul;
                        bd.Notes.Add($"��{mul:0.###} ���� {m.Source}");
                        break;

                    case StageStacking.Override:
                        cur = m.GetValue(ctx);
                        bd.Notes.Add($"=��дΪ {cur} ���� {m.Source}");
                        break;

                    case StageStacking.ClampMin:
                        var minV = m.GetValue(ctx);
                        cur = MathF.Max(cur, minV);
                        bd.Notes.Add($"��{minV} ��ͱ��� ���� {m.Source}");
                        break;

                    case StageStacking.ClampMax:
                        var maxV = m.GetValue(ctx);
                        cur = MathF.Min(cur, maxV);
                        bd.Notes.Add($"��{maxV} �������� ���� {m.Source}");
                        break;
                }
            }

            cur = (cur + addSum) * mulProd;
            return cur;
        }
    }
}


